#include "gtest/gtest.h"
#include "gmock/gmock.h"


int main(int argc, char* argv[]) {
    testing::InitGoogleTest(&argc, argv);
    std::cout << "AEDA 2018/2019 - Componente Individual 1 - Testes Unitarios Estudantes" << std::endl;
    return RUN_ALL_TESTS();;
}