#include "player.h"

//TODO
void Player::addBet(const Bet& b)
{

}

//TODO
unsigned Player::betsInNumber(unsigned num) const
{
	return 0;
}

//TODO
tabHBet Player::drawnBets(const tabHInt& draw) const
{
	tabHBet res;
	return res;
}
