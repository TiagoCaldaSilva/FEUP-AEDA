#include "bet.h"
#include <iostream>
#include <sstream>
using namespace std;


//TODO
bool Bet::contains(unsigned num) const
{
	return true;
}

//TODO
void Bet::generateBet(const vector<unsigned>& values, unsigned n)
{

}

//TODO
unsigned Bet::countRights(const tabHInt& draw) const
{
	return 0;
}
