#include "game.h"
#include <sstream>


//TODO
ostream &operator << (ostream &os, Circle &c1)
{
	return os;
}


//TODO
Game::Game(int h, vector<int> &points, vector<bool> &states)
{
}


//TODO
string Game::writeGame()
{
	return "";
}


//TODO
int Game::move()
{
	return 0;
}


//TODO
int Game::mostVisited()
{
	return 0;
}
